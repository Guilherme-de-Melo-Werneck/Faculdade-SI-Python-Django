# Bancos de dados ou bases de dados são conjuntos de arquivos relacionados entre si com registros sobre pessoas, lugares ou coisas. 
# São coleções organizadas de dados que se relacionam de forma a criar algum sentido (Informação) e dá mais eficiência durante uma
# pesquisa ou estudo. Crie uma aplicação python que possa gerar um banco de dados em Sqlite3 com o nome de ‘moleza.sqlite’ e 
# um CRUD em uma tabela com o nome de ‘pessoas’ com os seguintes campos abaixo:

# Campo                    Tipo de dados

# id                       Chave primária

# nome                      texto

# cpf                      caracter (11)



# Utilize como exemplo a aplicação da aula 13. Lembre-se que serão dois arquivos: um com a classe MyCrud e o outro com a aplicação.
# Crie uma pasta com "seu_nome" e os dois arquivos. Zipe-os (com .zip) e poste aqui

# Nome: Guilherme de Melo Werneck
# Matrícula: 2022101349

from rich import print
class MyCrud:
    def __init__(self, moleza):
        import sqlite3
        self.conexao = sqlite3.connect(moleza)
        self.cursor = self.conexao.cursor()

    def FecharDB(self):
        self.conexao.close()

    def Criar_Tabela(self):
        sql = """
            CREATE TABLE IF NOT EXISTS pessoas (
                id INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
                nome TEXT NOT NULL, 
                cpf VARCHAR(11)
            );   
        """
        self.cursor.execute(sql)
        print()
        print('TABELA CRIADA')

    def Inserir(self, nome, cpf):
            sql = """
            INSERT INTO pessoas(nome, cpf)
            VALUES(?, ?);
            """
            self.cursor.execute(sql, (nome, cpf))
            self.conexao.commit()
            print()
            print('[on green]---INFORMAÇÕES SALVA---[/]')

    def Selecionar(self):
        sql = """
            SELECT * FROM pessoas;
        """
        resultados = self.cursor.execute(sql)
        return resultados.fetchall()
    
    def Alterar(self, n_nome, c_cpf, i_id):
        sql = """
            UPDATE pessoas
            SET nome = ?, cpf = ?
            WHERE id = ?;
        """
        self.cursor.execute(sql, (n_nome, c_cpf, i_id))
        self.conexao.commit()
        print()
        print('[on green]---TABELA ALTERADA---[/]')
    
    def Deletar(self, d_id):
        sql = """
            DELETE FROM pessoas
            WHERE id = ?;
        """
        self.cursor.execute(sql, [d_id])
        self.conexao.commit()
        print()
        print('[on green]---iNFORMAÇÕES DELETADA---[/]')

        self.conexao.close()


