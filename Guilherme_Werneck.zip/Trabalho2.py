from My_Crud import MyCrud

my_crud = MyCrud('moleza.sqlite')
my_crud.Criar_Tabela()

while True:
    print('''
    ESCOLHA UMAS DAS OPÇÕES SUGERIDAS:
    1 - DELETAR
    2 - ALTERAR
    3 - LER
    4 - INCLUIR
    5 - SAIR
    ''')

    valor = input('=')

    if valor == '1':
        chave = input('ID: ')
        my_crud.Deletar(d_id = chave)

    elif valor == '2':
        chave = input('ID: ')
        cpf = input('CPF: ')
        nome = input ('NOME: ')
        my_crud.Alterar(i_id = chave, n_nome = nome, c_cpf = cpf)

    elif valor == '3':
        resultado = my_crud.Selecionar()
        print('RESULTADO:', resultado)

    elif valor == '4':
        nome = input('DIGITE UM NOME: ')
        cpf = input(f'DIGITE UM CPF: ')
        while len(cpf) != 11:
            print('CPF INVÁLIDO')
            cpf = input('DIGITE O CPF SEM PONTO OU TRAÇO:  ')            
        
        dados = {
            'nome': nome,
            'cpf':cpf,
        }
        my_crud.Inserir(nome,cpf)

    else:
        my_crud.FecharDB
        break

